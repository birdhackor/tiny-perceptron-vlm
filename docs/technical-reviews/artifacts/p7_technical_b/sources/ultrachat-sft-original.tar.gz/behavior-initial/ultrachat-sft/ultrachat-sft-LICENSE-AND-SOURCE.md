# ultrachat-sft 教學資料快照 v1

資料授權：**MIT**；本 repo 的 MIT 程式授權不改變資料授權。

保留上游註記、來源版本與原始授權文件；選樣、轉換與用途見包內 README／manifest，以及 Git 中的 assets/training/sources/ultrachat-sft.json。此包僅為 pilot，沒有模型訓練結果。
