## 10.8 沒附圖時，包裝會改變原文字計算嗎？

同一份文字模型、同一串三個文字編號，分別走原入口與加了圖片功能的包裝入口。沒有附圖時，希望兩者的候選分數逐項相同；這是介面接通前後的計算核對，不是問模型是否會寫文章。

```python
import torch
from tiny_perceptron.model import TinyLM, ModelConfig
from tiny_perceptron.multimodal import MultiModalLM

torch.manual_seed(0)
lm = TinyLM(ModelConfig(width=8)).eval()
multimodal = MultiModalLM(lm).eval()
ids = torch.tensor([1, 20, 30])
a = lm(ids[None])["logits"]
b = multimodal(ids)["logits"]
print("分數形狀", tuple(a.shape))
print("純文字入口相同", torch.equal(a, b))
```

`MultiModalLM(lm)` 包住的是同一個文字模型，不是另一份新權重。兩邊都設為 `eval()`，本例避開訓練模式下的隨機行為。原入口以 `ids[None]` 補批次軸，包裝則在內部處理它。

三個編號沒有圖片標記，輸出都是 `(1,3,264)`：一筆、三位置、264 個文字候選。`torch.equal` 印 True，確認包裝沿用相同文字計算。即使權重隨機、兩路都答不好，一致性仍可以成立；它和答案正確是兩個問題。

如果放圖片標記卻沒有圖片，應報缺資料。嘗試 `multimodal(torch.tensor([1,5,4]))` 會出現佔位標記缺少配對圖片／聲音的錯誤，不能默默把它當普通字詞。

訓練後若開放文字權重，計算可能合理地改變；是否保住舊技能，要用固定文字題核對答案。若改包裝後立即不同，先查輸入、位置與運算路徑；若只在訓練後退步，再查更新範圍與資料。練習換成 `[1,40,50]`，預期形狀與一致性仍相同。

<details>
<summary>回顧與查證</summary>

可回顧：[10.7模態標記與展開](10.md#10.7)、[4.6輸出候選分數](04.md#4.6)、[16.8](16.md#16.8)。

</details>

